import React from 'react';

const getTheatres = (event) => {  
  const theatre_options = [];
  theatre_options.push(<option key=''>-- Select Theatre --</option>);
              
    let movie_name = event.target.value; 
    console.log(movie_name)
    for(let d1 in bookingData.movies) {
      let movie1 = bookingData.movies[d1];              
      if(movie1.name === movie_name) {                          
        for(let t in bookingData.movies[d1].theatres) { 
          theatre_options.push(<option value={t}>{t}</option>);                   
        }
      }       
    } 
    console.log(theatre_options)
  }

  return (
    <div>{theatre_options}</div>
  );

};

export default getTheatres;
