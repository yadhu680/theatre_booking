import React, { Component } from 'react';
import './style.css';
import './booking.css';

const divStyle = {
  display: 'none'
};

const data = {  
  "movies": [
    { 
    	"name":"Titanic", 
    	"theatres": {
	    	"Lulu" : {
	    		"timings": ["09.00 AM", "12.00 PM", "04.00 PM", "08:00 PM"]	    	
	    	},
	    	"Oberon": {
	    		"timings": ["10.00 AM", "01.00 PM", "04.30 PM", "08:30 PM"]
	    	},

	    	"Gold Souk" : {
	    		"timings": ["10.40 AM", "01.30 PM", "04.45 PM", "09:15 PM"]
	    	} 
    	},
    },
    { 
    	"name":"Spiderman", 
		"theatres":{
			"Vanitha" : {
				"timings": ["10.00 AM", "01.00 PM", "04.45 PM", "08:15 PM"]	    		    
	    	},

	    	"Carnival Cinemas": {
	    		"timings": ["10.40 AM", "02.00 PM", "04.45 PM", "09:15 PM"]
	    	},

	    	"Padma" : {
	    		"timings": ["09.45 AM", "12.15 PM", "04.00 PM", "08:30 PM"]		    		
	    	} 
    	},
	},
  ],
 };

class App extends Component {
          
    constructor(props){
      super(props);

      this.state = {
        totalSeatCount : 140,
        maxTicketToBook: 6,
        movie_options: [],
        theatre_options: [],
        theatre_timings: [],        
        array: [],
        selectedTime: '',
        count: 0,
        labelClickCount: 0
      }     
      
      this.selectTimings = this.selectTimings;    
      this.handleChange = this.handleChange; 
      this.getAvailableTicketCount = this.getAvailableTicketCount; 
    }
    getJSONData = () => {
      const stringData = JSON.stringify(data);
      return JSON.parse(stringData);
    }
    componentDidMount() {
      const seats = ['A','B','C','D','E','F','G','H','I','J'];
      const arr = [];
      for(let i = 1; i < 15; i ++){
          seats.forEach(function(element) {
              arr.push(element+i); 
          });
      }
      this.setState({array: arr});
                
      const bookingData = this.getJSONData();            
      const movieOptions = [];
      movieOptions.push(<option key=''>-- Select Movie --</option>);
      for(var d in bookingData.movies) {
          const movie = bookingData.movies[d];          
          movieOptions.push(<option key={movie.name} value={movie.name}>{movie.name}</option>);                  
      }
      this.setState({movie_options:  movieOptions});

      const bookedSeats = this.getRandomBookedSeats(arr, this.state.totalSeatCount); 
      this.setBookedSeats(bookedSeats);

      
      const labels = document.getElementsByTagName("label");
      for (let i = 0; i < labels.length; i ++) {                            
          labels[i].addEventListener("click", this.checkSeat);            
      }
      
    }

    handleChange = (e) => {
      let id = e.target.id;          
      const selected_seat = document.getElementById("numSeats").value;  
                           
      if(e.target.checked === true) {  
        if(selected_seat > 0) {                  
          if(this.state.count >= selected_seat) {
              document.getElementById(id).labels[0].style.backgroundColor = '#FFF';
              document.getElementById(id).setAttribute('checked', false);                    
              alert("You can't select more than of your selected seat ("+selected_seat+")");
              return false;
          }else if(this.state.count >= this.state.maxTicketToBook) {                    
              document.getElementById(id).labels[0].style.backgroundColor = '#FFF';  
              document.getElementById(id).setAttribute('checked', false);                  
              alert("You can select max "+this.state.maxTicketToBook+" seats at a time");
              return false;
          }else{            
            this.setState({
              count: ++ this.state.count
            });        
            document.getElementById(id).setAttribute('checked', true);
          }
        }else{
          document.getElementById(id).labels[0].style.backgroundColor = '#FFF'; 
          document.getElementById(id).setAttribute('checked', false);
          alert("Please select no. of seats");
          return false;
        }
      }else{
        this.setState({
          count: -- this.state.count
        });
        document.getElementById(id).setAttribute('checked', false);
        return false;                
      }
      this.setState({count: this.state.count});       
    }
    
    getTheatres = (event) => { 
      const bookingData = this.getJSONData();
      const theatreOptions = [];    
      theatreOptions.push(<option key=''>-- Select Theatre --</option>);          
      let movie_name = event.target.value;           
      for(var d1 in bookingData.movies) {
        let movie1 = bookingData.movies[d1];              
        if(movie1.name === movie_name) {                          
          for(var t in bookingData.movies[d1].theatres) { 
            theatreOptions.push(<option key={t} value={t}>{t}</option>);                   
          }
        }       
      } 
      this.setState({theatre_options:  theatreOptions});      
    }    
 
    getTimings = (event) => {
      const bookingData = this.getJSONData();
      let theatre_name = event.target.value; 
      const theatreTimings = [];            
      for(var d in bookingData.movies) {                                
          for(var t in bookingData.movies[d].theatres) {                          
              if(t === theatre_name) {
                  var timings = bookingData.movies[d].theatres[t].timings;                                          
                  for(var tim in timings) {
                      let id = "tim"+tim;
                      theatreTimings.push(<a key={id} className='timing' id={id} onClick={this.selectTimings} >{timings[tim]}</a>);                      
                  }                   
              }                    
          }                    
      } 
      this.setState({theatre_timings:  theatreTimings}); 
      document.getElementById("sel_options").style.display = "block";          
    }    
  
    selectTimings = (event) => {                
      let id = event.target.id;
      var elem1 = document.getElementById(id);           
      elem1.style.backgroundColor = "yellow";
      elem1.style.color = "#000";
      elem1.style.border = 0;
      let divs = document.getElementsByClassName("timing");         
      Object.entries(divs).map(( object ) => {         
          if("tim"+object[0] !== id) {                    
              let elem2 = document.getElementById("tim"+object[0]);
              elem2.style.background = "none";
              elem2.style.color = "#FFF"; 
              elem2.style.border = "1px solid #FFF";                
          }
          return true;
      });
      
      const bookedSeats = this.getRandomBookedSeats(this.state.array, 80);      
      let checkboxes = document.getElementsByTagName("input");
      bookedSeats.forEach(function(element) {           
          for (let i = 0; i < checkboxes.length; i++) {
              if (checkboxes[i].type === "checkbox") {
                  if(checkboxes[i].id === element){
                      checkboxes[i].disabled = false;
                  }
              }
          } 
      });

      const randomSeats = this.getRandomBookedSeats(this.state.array, Math.floor(Math.random()*110));      
      this.setBookedSeats(randomSeats);
      this.setState({selectedTime: elem1.innerHTML});
  }

  getRandomBookedSeats = (arr, n) => {  
      var result = new Array(n),
          len = arr.length,
          taken = new Array(len);
      if (n > len)
          throw new RangeError("getRandom: more elements taken than available");
      while (n--) {
          var x = Math.floor(Math.random() * len);
          result[n] = arr[x in taken ? taken[x] : x];
          taken[x] = --len in taken ? taken[len] : len;
      }
      return result;
  }
    
  setBookedSeats = (bookedSeats) => {
    var checkboxes = document.getElementsByTagName("input");
    bookedSeats.forEach(function(element) {           
        for (let i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].type === "checkbox") {
                if(checkboxes[i].id === element){
                    checkboxes[i].disabled = true;
                }
            }
        }               
    });
  }
 
  confirmBooking = () => {
    if(this.state.selectedTime !== ""){
      let selected_seat_count = document.getElementById("numSeats").value; 
      if(selected_seat_count > 0) {
          if(selected_seat_count > this.state.maxTicketToBook) {
              alert("You can book only "+this.state.maxTicketToBook+" tickets");
              return false;
          }
          let availableTicketCount = this.getAvailableTicketCount();            
                      
          if(selected_seat_count > availableTicketCount) {
              alert("Only "+availableTicketCount+" seats available.")
          }
          alert('Your Booking Confirmed!')
      }else{
          alert('Please select no. of seats');
      }
    }else{
      alert('Please select show time');
    }

    return false;
  }

  getAvailableTicketCount = () => {
    const checkboxes = document.querySelectorAll("input");                      
    let count = 0;                    
    for (let i = 0; i < checkboxes.length; i++) {      
        if (checkboxes[i].attributes[0].value === "checkbox") {                    
            if(checkboxes[i].disabled !== true) {
                ++ count;
            }                    
        }
    }                                   
    return count;                                
  }
  
  checkSeat = () => {      
    const availableTCount = this.getAvailableTicketCount();
    const check_boxes = document.querySelectorAll("input");                    
    let checkedBox = 0;             
    for (let i = 0; i < check_boxes.length; i ++) {
      if (check_boxes[i].attributes[0].value === "checkbox") {                    
        if(check_boxes[i].checked === true){
          checkedBox ++;
        }    
      }
    }             
    if(checkedBox === availableTCount) {
      if(this.state.labelClickCount >= 5){
          alert('Sorry! Seats are occupied. Try a different time/date');                    
      }else { 
        this.setState({
          labelClickCount: this.state.labelClickCount + 1
        });                           
      }
    }            
  }

render() {

  return (
    <div className="App">
        <h1>Movie Seat Selection</h1> 
        <div className="container">
          <div className="w3ls-reg">         
            <div className="booking-filter">
                <h2>Select Movie</h2>
                <div className="mr_agilemain">
                    <div className="agileits-left styled-select white semi-square">                       
                        <select name="movies" id="movies" onChange={this.getTheatres}>
                          {this.state.movie_options}                                                    
                        </select>
                    </div>
                    <div className="agileits-right styled-select white semi-square">
                        <select name="theatres" id="theatres" onChange={this.getTimings}> 
                            {this.state.theatre_options}                                          
                        </select>
                    </div>
                </div>
                <div id="sel_options" style={divStyle}>
                    <h2>Select Timings</h2>
                    <div className="mr_agilemain timings" id="timings">  
                      {this.state.theatre_timings}                      
                    </div>                    
                    <h2>Select No. of Seats</h2>
                    <div className="mr_agilemain timings">
                        <div className="agileits-left">                       
                            <input className="semi-square" type="number" id="numSeats" required min="1" />                        
                        </div>
                        
                    </div>
                    <button onClick={this.confirmBooking}>CONFIRM</button><br /><br />
                </div>
            </div>           
            <div className="seat-layout">                                
                
            <ol className="cabin">
              <li>
                  <ol className="seats center">
                  <li>&nbsp;</li>
                  <li className="seat">
                    1
                  </li> 
                  <li className="seat">
                    2
                  </li>
                  <li className="seat">
                    3
                  </li>
                  <li className="seat">
                    4
                  </li>
                  <li className="seat">
                    5
                  </li>
                  <li className="seat">
                    6
                  </li>
                  <li className="seat">
                    7
                  </li>
                  <li className="seat">
                    8
                  </li>
                  <li className="seat">
                    9
                  </li>
                  <li className="seat">
                    10
                  </li>
                  <li className="seat">
                    11
                  </li>
                  <li className="seat">
                    12
                  </li>
                  <li className="seat">
                    13
                  </li>
                  <li className="seat">
                    14
                  </li>
              </ol>
              </li>

      <br />
    <h3>Prime - Rs. 230.00</h3><br />
    <li className="row row--1">
      <ol className="seats" type="A">
        <li>          
          <label>J</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J1" />
          <label htmlFor="J1">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J2" />
          <label htmlFor="J2">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J3" />
          <label htmlFor="J3">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J4" />
          <label htmlFor="J4">&nbsp;</label>
        </li> 
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J5" />
          <label htmlFor="J5">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J6" />
          <label htmlFor="J6">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J7" />
          <label htmlFor="J7">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J8" />
          <label htmlFor="J8">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J9" />
          <label htmlFor="J9">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J10" />
          <label htmlFor="J10">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J11" />
          <label htmlFor="J11">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J12" />
          <label htmlFor="J12">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J13" />
          <label htmlFor="J13">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="J14" />
          <label htmlFor="J14">&nbsp;</label>
        </li>
      </ol>
    </li>
    <li className="row row--2">
      <ol className="seats" type="A">
        <li style={{paddingRight: '5px'}}>          
          <label>I</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I1" />
          <label htmlFor="I1">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I2" />
          <label htmlFor="I2">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I3" />
          <label htmlFor="I3">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I4" />
          <label htmlFor="I4">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I5" />
          <label htmlFor="I5">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I6" />
          <label htmlFor="I6">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I7" />
          <label htmlFor="I7">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I8" />
          <label htmlFor="I8">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I9" />
          <label htmlFor="I9">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I10" />
          <label htmlFor="I10">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I11" />
          <label htmlFor="I11">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I12" />
          <label htmlFor="I12">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I13" />
          <label htmlFor="I13">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="I14" />
          <label htmlFor="I14">&nbsp;</label>
        </li>
      </ol>
    </li>
    <li className="row row--3">
      <ol className="seats" type="A">
        <li>          
          <label>H</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H1" />
          <label htmlFor="H1">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H2" />
          <label htmlFor="H2">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H3" />
          <label htmlFor="H3">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H4" />
          <label htmlFor="H4">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H5" />
          <label htmlFor="H5">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H6" />
          <label htmlFor="H6">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H7" />
          <label htmlFor="H7">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H8" />
          <label htmlFor="H8">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H9" />
          <label htmlFor="H9">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H10" />
          <label htmlFor="H10">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H11" />
          <label htmlFor="H11">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H12" />
          <label htmlFor="H12">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H13" />
          <label htmlFor="H13">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="H14" />
          <label htmlFor="H14">&nbsp;</label>
        </li>
      </ol>
    </li>
    <li className="row row--4">
      <ol className="seats" type="A">
        <li>          
          <label>G</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G1" />
          <label htmlFor="G1">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G2" />
          <label htmlFor="G2">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G3" />
          <label htmlFor="G3">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G4" />
          <label htmlFor="G4">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G5" />
          <label htmlFor="G5">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G6" />
          <label htmlFor="G6">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G7" />
          <label htmlFor="G7">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G8" />
          <label htmlFor="G8">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G9" />
          <label htmlFor="G9">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G10" />
          <label htmlFor="G10">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G11" />
          <label htmlFor="G11">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G12" />
          <label htmlFor="G12">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G13" />
          <label htmlFor="G13">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="G14" />
          <label htmlFor="G14">&nbsp;</label>
        </li>
      </ol>
    </li>
    <li className="row row--5">
      <ol className="seats" type="A">
        <li>          
          <label>F</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F1" />
          <label htmlFor="F1">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F2" />
          <label htmlFor="F2">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F3" />
          <label htmlFor="F3">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F4" />
          <label htmlFor="F4">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F5" />
          <label htmlFor="F5">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F6" />
          <label htmlFor="F6">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F7" />
          <label htmlFor="F7">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F8" />
          <label htmlFor="F8">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F9" />
          <label htmlFor="F9">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F10" />
          <label htmlFor="F10">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F11" />
          <label htmlFor="F11">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F12" />
          <label htmlFor="F12">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F13" />
          <label htmlFor="F13">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="F14" />
          <label htmlFor="F14">&nbsp;</label>
        </li>
      </ol>
    </li>
    <li className="row row--6">
      <ol className="seats" type="A">
        <li>          
          <label>E</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E1" />
          <label htmlFor="E1">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E2" />
          <label htmlFor="E2">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E3" />
          <label htmlFor="E3">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E4" />
          <label htmlFor="E4">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E5" />
          <label htmlFor="E5">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E6" />
          <label htmlFor="E6">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E7" />
          <label htmlFor="E7">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E8" />
          <label htmlFor="E8">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E9" />
          <label htmlFor="E9">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E10" />
          <label htmlFor="E10">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E11" />
          <label htmlFor="E11">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="E12" />
          <label htmlFor="E12">&nbsp;</label>
        </li>
        
       
      </ol>
    </li>
    
    <li className="row row--7">
      <ol className="seats" type="A">
         <li>          
          <label>D</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D1" />
          <label htmlFor="D1">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D2" />
          <label htmlFor="D2">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D3" />
          <label htmlFor="D3">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D4" />
          <label htmlFor="D4">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D5" />
          <label htmlFor="D5">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D6" />
          <label htmlFor="D6">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D7" />
          <label htmlFor="D7">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D8" />
          <label htmlFor="D8">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D9" />
          <label htmlFor="D9">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D10" />
          <label htmlFor="D10">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D11" />
          <label htmlFor="D11">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="D12" />
          <label htmlFor="D12">&nbsp;</label>
        </li>
        
      </ol>
    </li>
    <br />
    <h3>Classic - Rs. 156.00</h3><br />
    <li className="row row--8">
      <ol className="seats" type="A">
         <li>          
          <label>C</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C1" />
          <label htmlFor="C1">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C2" />
          <label htmlFor="C2">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C3" />
          <label htmlFor="C3">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C4" />
          <label htmlFor="C4">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C5" />
          <label htmlFor="C5">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C6" />
          <label htmlFor="C6">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C7" />
          <label htmlFor="C7">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C8" />
          <label htmlFor="C8">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C9" />
          <label htmlFor="C9">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C10" />
          <label htmlFor="C10">&nbsp;</label>
        </li>
        <li className="seat">
          <input type="checkbox" onChange={this.handleChange} id="C11" />
          <label htmlFor="C11">&nbsp;</label>
        </li>
      </ol>
    </li>
              <li className="row row--9">
                  
                <ol className="seats" type="A">
                  <li>          
                    <label>B</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B1" />
                    <label htmlFor="B1">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B2" />
                    <label htmlFor="B2">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B3" />
                    <label htmlFor="B3">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B4" />
                    <label htmlFor="B4">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B5" />
                    <label htmlFor="B5">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B6" />
                    <label htmlFor="B6">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B7" />
                    <label htmlFor="B7">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B8" />
                    <label htmlFor="B8">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B9" />
                    <label htmlFor="B9">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B10" />
                    <label htmlFor="B10">&nbsp;</label>
                  </li>
                  <li className="seat">
                    <input type="checkbox" onChange={this.handleChange} id="B11" />
                    <label htmlFor="B11">&nbsp;</label>
                  </li>
                </ol>
              </li>
                <li className="row row--10">
                  <ol className="seats" type="A">
                    <li>          
                      <label>A</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A1" />
                      <label htmlFor="A1">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A2" />
                      <label htmlFor="A2">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A3" />
                      <label htmlFor="A3">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A4" />
                      <label htmlFor="A4">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A5" />
                      <label htmlFor="A5">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A6" />
                      <label htmlFor="A6">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A7" />
                      <label htmlFor="A7">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A8" />
                      <label htmlFor="A8">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A9" />
                      <label htmlFor="A9">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A10" />
                      <label htmlFor="A10">&nbsp;</label>
                    </li>
                    <li className="seat">
                      <input type="checkbox" onChange={this.handleChange} id="A11" />
                      <label htmlFor="A11">&nbsp;</label>
                    </li>
                  </ol>
                </li>
              </ol>
              <div className="screen">
                  <h2 className="wthree">Screen this way</h2>
              </div>                        
            </div>            
            <div className="seat-availability">
                <h2>Seat Availability</h2>
                <ul className="seat_w3ls">
                    <li className="smallBox greenBox">Your Booked Seats</li>
                    <li className="smallBox lightGreenBox">Possible Seat Combinations</li>                    
                    <li className="smallBox emptyBox">Available Seats</li>
                    <li className="smallBox bookedBox">Unavailable Seats</li>
                </ul>
            </div>           
          </div>
        </div>
    </div>
    
  );
}
}

export default App;
